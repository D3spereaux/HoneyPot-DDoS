module Racket
end

require File.dirname(__FILE__) + '/racket/racket.rb'
